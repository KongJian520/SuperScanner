import path from 'path';
import {defineConfig} from 'vite';
import react from "@vitejs/plugin-react";
import tailwindcss from '@tailwindcss/vite';

const host = process.env.TAURI_DEV_HOST;

export default defineConfig(({ mode }) => {

  return {
    plugins: [react(),tailwindcss()],
    clearScreen: false,
    define: {

    },
    resolve: {
      alias: {
        '@': path.resolve(process.cwd(), 'src'),
      }
    },
    server: {
      port: 1420,
      strictPort: true,
      host: host || false,
      hmr: host
        ? {
          protocol: "ws",
          host,
          port: 1421,
        }
        : undefined,
      watch: {
        ignored: ["**/src-tauri/**"],
      },
    },
  };
});
